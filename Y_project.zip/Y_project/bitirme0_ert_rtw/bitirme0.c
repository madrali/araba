/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: bitirme0.c
 *
 * Code generated for Simulink model 'bitirme0'.
 *
 * Model version                  : 5.96
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Thu Jun 20 03:15:04 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "bitirme0.h"
#include "bitirme0_types.h"
#include "bitirme0_private.h"
#include "rtwtypes.h"
#include "stm_timer_ll.h"
#include <math.h>

/* Block states (default storage) */
DW_bitirme0_T bitirme0_DW;

/* Real-time model */
static RT_MODEL_bitirme0_T bitirme0_M_;
RT_MODEL_bitirme0_T *const bitirme0_M = &bitirme0_M_;

/* Forward declaration for local functions */
static void bitirme0_SystemCore_setup(stm32cube_blocks_PWMOutput_bi_T *obj);
real32_T rt_roundf_snf(real32_T u)
{
  real32_T y;
  if ((real32_T)fabs(u) < 8.388608E+6F) {
    if (u >= 0.5F) {
      y = (real32_T)floor(u + 0.5F);
    } else if (u > -0.5F) {
      y = u * 0.0F;
    } else {
      y = (real32_T)ceil(u - 0.5F);
    }
  } else {
    y = u;
  }

  return y;
}

static void bitirme0_SystemCore_setup(stm32cube_blocks_PWMOutput_bi_T *obj)
{
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<S7>/PWM Output' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<S7>/PWM Output' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  enableTimerChannel1(obj->TimerHandle, ENABLE_CH);
  enableTimerChannel2(obj->TimerHandle, ENABLE_CH);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<S7>/PWM Output' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function */
void bitirme0_step(void)
{
  GPIO_TypeDef * portNameLoc;
  int32_T c;
  real32_T tmp;
  uint32_T freq;

  /* MATLABSystem: '<S11>/Digital Port Write' incorporates:
   *  Constant: '<Root>/Constant'
   */
  portNameLoc = GPIOA;
  if (bitirme0_P.Constant_Value != 0.0F) {
    c = 128;
  } else {
    c = 0;
  }

  LL_GPIO_SetOutputPin(portNameLoc, (uint32_T)c);
  LL_GPIO_ResetOutputPin(portNameLoc, ~(uint32_T)c & 128U);

  /* End of MATLABSystem: '<S11>/Digital Port Write' */

  /* MATLABSystem: '<S7>/PWM Output' incorporates:
   *  Constant: '<Root>/Constant2'
   *  Constant: '<Root>/Constant4'
   *  Constant: '<Root>/sag_motor_duty'
   */
  tmp = rt_roundf_snf(bitirme0_P.Constant2_Value);
  if (tmp < 4.2949673E+9F) {
    if (tmp >= 0.0F) {
      freq = (uint32_T)tmp;
    } else {
      freq = 0U;
    }
  } else {
    freq = MAX_uint32_T;
  }

  freq = checkFrequencyAndDutyCycleLimits(bitirme0_DW.obj.TimerHandle, freq);
  setFrequencyAccToInput(bitirme0_DW.obj.TimerHandle, freq);
  setDutyCycleInPercentageChannel1(bitirme0_DW.obj.TimerHandle,
    bitirme0_P.Constant4_Value);
  setDutyCycleInPercentageChannel2(bitirme0_DW.obj.TimerHandle,
    bitirme0_P.sag_motor_duty_Value);

  /* End of MATLABSystem: '<S7>/PWM Output' */

  /* MATLABSystem: '<S9>/Digital Port Write' incorporates:
   *  Constant: '<Root>/Constant6'
   */
  portNameLoc = GPIOA;
  if (bitirme0_P.Constant6_Value != 0.0F) {
    c = 256;
  } else {
    c = 0;
  }

  LL_GPIO_SetOutputPin(portNameLoc, (uint32_T)c);
  LL_GPIO_ResetOutputPin(portNameLoc, ~(uint32_T)c & 256U);

  /* End of MATLABSystem: '<S9>/Digital Port Write' */

  /* MATLABSystem: '<S13>/Digital Port Write' incorporates:
   *  Constant: '<Root>/Constant7'
   */
  portNameLoc = GPIOA;
  if (bitirme0_P.Constant7_Value != 0.0F) {
    c = 1024;
  } else {
    c = 0;
  }

  LL_GPIO_SetOutputPin(portNameLoc, (uint32_T)c);
  LL_GPIO_ResetOutputPin(portNameLoc, ~(uint32_T)c & 1024U);

  /* End of MATLABSystem: '<S13>/Digital Port Write' */

  /* MATLABSystem: '<S15>/Digital Port Write' incorporates:
   *  Constant: '<Root>/Constant8'
   */
  portNameLoc = GPIOB;
  if (bitirme0_P.Constant8_Value != 0.0F) {
    c = 8;
  } else {
    c = 0;
  }

  LL_GPIO_SetOutputPin(portNameLoc, (uint32_T)c);
  LL_GPIO_ResetOutputPin(portNameLoc, ~(uint32_T)c & 8U);

  /* End of MATLABSystem: '<S15>/Digital Port Write' */
}

/* Model initialize function */
void bitirme0_initialize(void)
{
  /* Start for MATLABSystem: '<S7>/PWM Output' */
  bitirme0_DW.obj.isInitialized = 0;
  bitirme0_DW.obj.matlabCodegenIsDeleted = false;
  bitirme0_SystemCore_setup(&bitirme0_DW.obj);
}

/* Model terminate function */
void bitirme0_terminate(void)
{
  /* Terminate for MATLABSystem: '<S7>/PWM Output' */
  if (!bitirme0_DW.obj.matlabCodegenIsDeleted) {
    bitirme0_DW.obj.matlabCodegenIsDeleted = true;
    if ((bitirme0_DW.obj.isInitialized == 1) && bitirme0_DW.obj.isSetupComplete)
    {
      disableCounter(bitirme0_DW.obj.TimerHandle);
      disableTimerInterrupts(bitirme0_DW.obj.TimerHandle, 0);
      disableTimerChannel1(bitirme0_DW.obj.TimerHandle, ENABLE_CH);
      disableTimerChannel2(bitirme0_DW.obj.TimerHandle, ENABLE_CH);
    }
  }

  /* End of Terminate for MATLABSystem: '<S7>/PWM Output' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
