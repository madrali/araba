/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: bitirme0_data.c
 *
 * Code generated for Simulink model 'bitirme0'.
 *
 * Model version                  : 5.96
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Thu Jun 20 03:15:04 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "bitirme0.h"

/* Block parameters (default storage) */
P_bitirme0_T bitirme0_P = {
  /* Expression: 50
   * Referenced by: '<Root>/Constant4'
   */
  50.0,

  /* Computed Parameter: Constant_Value
   * Referenced by: '<Root>/Constant'
   */
  1.0F,

  /* Computed Parameter: Constant2_Value
   * Referenced by: '<Root>/Constant2'
   */
  1.0F,

  /* Computed Parameter: sag_motor_duty_Value
   * Referenced by: '<Root>/sag_motor_duty'
   */
  80.0F,

  /* Computed Parameter: Constant6_Value
   * Referenced by: '<Root>/Constant6'
   */
  1.0F,

  /* Computed Parameter: Constant7_Value
   * Referenced by: '<Root>/Constant7'
   */
  1.0F,

  /* Computed Parameter: Constant8_Value
   * Referenced by: '<Root>/Constant8'
   */
  0.0F
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
